package com.project;

import com.project.controller.LoginController;
import com.project.model.Model;
import com.project.view.DashboardView;
import com.project.view.ItemView;
import com.project.view.LoginView;

public class App {
    public static void main(String[] args) {
        Model model = new Model(); // create the model
        LoginView loginWindow = new LoginView(); // create the login window view
        DashboardView dashboard = new DashboardView(loginWindow.window); // initialize the dashboard
        LoginController loginController = new LoginController(model, loginWindow, dashboard); // create controller
        ItemView itemView = new ItemView(loginWindow.window);

        // Hook up the buttons to the controller
        loginWindow.init();
        loginWindow.enterBtn.addActionListener(loginController);
        loginWindow.createAccBtn.addActionListener(loginController);

        // Optional: Uncomment if needed
        // ItemViewController itemViewController = new ItemViewController(model,
        // loginWindow, itemView, dashboard);
        // DashboardController dashboardController = new DashboardController(model,
        // dashboard);
    }
}
