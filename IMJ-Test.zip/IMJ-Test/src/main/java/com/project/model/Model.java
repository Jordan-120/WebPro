package com.project.model;

import java.sql.*;

public class Model {
    Part part = null;
    Material material = null;
    WorkOrder workOrder = null;

    public static Connection databaseConnection() throws SQLException {
        String url = "jdbc:sqlite:database.db";
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.out.println("SQLite JDBC driver not found: " + e.getMessage());
        }
        Connection connection = DriverManager.getConnection(url);
        CreateDB.createDatabase(connection);
        return connection;
    }

    public static boolean createAccount(String username, String password) {
        String query = "INSERT INTO Person (username, password_hash) VALUES (?, ?)";
        try (Connection db = databaseConnection();
                PreparedStatement ps = db.prepareStatement(query)) {

            ps.setString(1, username);
            ps.setString(2, password);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public static boolean enterAccount(String username, String password) {
        String query = "SELECT * FROM Person WHERE username = ? AND password_hash = ?";
        try (Connection db = databaseConnection();
                PreparedStatement ps = db.prepareStatement(query)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet r = ps.executeQuery()) {
                return r.next();
            }
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public Object searchByID(int IDInput, String searchType) {
        String query = searchType.equals("Parts") ? "SELECT * FROM Parts WHERE part_id = ?"
                : "SELECT * FROM Materials WHERE mat_id = ?";

        try (Connection db = databaseConnection();
                PreparedStatement ps = db.prepareStatement(query)) {

            ps.setInt(1, IDInput);
            try (ResultSet r = ps.executeQuery()) {
                if (r.next()) {
                    if (searchType.equals("Parts")) {
                        part = new Part(
                                r.getInt("part_id"),
                                r.getString("part_name"),
                                r.getInt("serial_num"),
                                r.getString("dimensions"),
                                r.getInt("rack_num"),
                                r.getInt("quantity"),
                                r.getInt("mat_id"));
                        return part;
                    } else {
                        material = new Material(
                                r.getInt("mat_id"),
                                r.getString("mat_name"),
                                r.getString("sub_type"),
                                r.getFloat("diameter"),
                                r.getInt("rack_num"),
                                r.getInt("length_inches"));
                        return material;
                    }
                }
                return null;
            }
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public Object searchByName(String nameInput, String searchType) {
        String query = searchType.equals("Parts") ? "SELECT * FROM Parts WHERE part_name = ?"
                : "SELECT * FROM Materials WHERE mat_name = ?";

        try (Connection db = databaseConnection();
                PreparedStatement ps = db.prepareStatement(query)) {

            ps.setString(1, nameInput);
            try (ResultSet r = ps.executeQuery()) {
                if (r.next()) {
                    if (searchType.equals("Parts")) {
                        part = new Part(
                                r.getInt("part_id"),
                                r.getString("part_name"),
                                r.getInt("serial_num"),
                                r.getString("dimensions"),
                                r.getInt("rack_num"),
                                r.getInt("quantity"),
                                r.getInt("mat_id"));
                        return part;
                    } else {
                        material = new Material(
                                r.getInt("mat_id"),
                                r.getString("mat_name"),
                                r.getString("sub_type"),
                                r.getFloat("diameter"),
                                r.getInt("rack_num"),
                                r.getInt("length_inches"));
                        return material;
                    }
                }
                return null;
            }
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public static boolean displayItemInfo() {
        try (Connection db = databaseConnection()) {
            return true;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public static boolean displayWorkOrders() {
        String query = "SELECT * FROM WorkOrders";
        try (Connection db = databaseConnection();
                Statement s = db.createStatement();
                ResultSet r = s.executeQuery(query)) {

            if (r.next()) {
                int wo_id = r.getInt("work_order_id");
                String wo_type = r.getString("wo_type");
                Date wo_date = r.getDate("order_date");
                int customer_id = r.getInt("cust_id");
                int part_id = r.getInt("part_id");
            }

            return true;
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        }
    }

    public static boolean addNewItem() {
        return true;
    }

    public static boolean removeItem() {
        return true;
    }

    public static boolean generateTopItems() {
        return true;
    }
}