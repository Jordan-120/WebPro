package com.project.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DashboardView {
    public JFrame window;
    public JPanel dashboard;
    public JTextField searchBar;
    public JButton btnSearch, btnInventoryList, btnWorkOrders, btnInvoices;
    public JComboBox<String> searchSelector;

    private JPopupMenu profileMenu;
    private JMenuItem changeUserItem, settingsItem, logoutItem;

    public DashboardView(JFrame window) {
        this.window = window;
    }

    public void initializeDashboard(ActionListener listener) {
        window.setTitle("Dashboard");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Define light brown color
        Color lightBrown = new Color(210, 180, 140);

        // Main container layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(lightBrown);

        // Top-right profile bar
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topBar.setBackground(lightBrown);
        JButton profileButton = new JButton("☰");
        profileButton.setFocusPainted(false);
        profileButton.setMargin(new Insets(2, 8, 2, 8));
        topBar.add(profileButton);

        profileMenu = new JPopupMenu();
        changeUserItem = new JMenuItem("Change User");
        settingsItem = new JMenuItem("Settings");
        logoutItem = new JMenuItem("Log Out");

        profileMenu.add(changeUserItem);
        profileMenu.add(settingsItem);
        profileMenu.add(logoutItem);

        profileButton.addActionListener(e -> profileMenu.show(profileButton, 0, profileButton.getHeight()));
        changeUserItem.addActionListener(listener);
        settingsItem.addActionListener(listener);
        logoutItem.addActionListener(listener);

        mainPanel.add(topBar, BorderLayout.NORTH);

        // Dashboard content with GridBagLayout
        dashboard = new JPanel();
        dashboard.setLayout(new GridBagLayout());
        dashboard.setBackground(lightBrown);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Title
        JLabel db_title = new JLabel("Welcome");
        db_title.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        dashboard.add(db_title, gbc);

        // Search Bar
        searchBar = new JTextField(20);
        gbc.gridy = 1;
        dashboard.add(searchBar, gbc);

        btnSearch = new JButton("Search");
        gbc.gridx = 1;
        dashboard.add(btnSearch, gbc);

        // Search Selector (dropdown)
        searchSelector = new JComboBox<>(new String[] { "Parts", "Materials", "Sales", "WorkOrders" });
        gbc.gridx = 0;
        gbc.gridy = 2;
        dashboard.add(searchSelector, gbc);

        // Action Buttons
        btnInventoryList = new JButton("Inventory List");
        gbc.gridx = 0;
        gbc.gridy = 3;
        dashboard.add(btnInventoryList, gbc);

        btnWorkOrders = new JButton("Work Orders");
        gbc.gridy = 4;
        dashboard.add(btnWorkOrders, gbc);

        btnInvoices = new JButton("Invoices");
        gbc.gridy = 5;
        dashboard.add(btnInvoices, gbc);

        mainPanel.add(dashboard, BorderLayout.CENTER);

        window.getContentPane().removeAll();
        window.add(mainPanel);
        window.revalidate();
        window.repaint();
    }

    public JMenuItem getChangeUserItem() {
        return changeUserItem;
    }

    public JMenuItem getSettingsItem() {
        return settingsItem;
    }

    public JMenuItem getLogoutItem() {
        return logoutItem;
    }
}
