package com.project.controller;

import javax.swing.JOptionPane;

import com.project.model.Model;
import com.project.view.DashboardView;
import com.project.view.LoginView;

import java.awt.event.*;

public class LoginController implements ActionListener {
    private Model model;
    private LoginView loginWindow;
    private DashboardView dashboard;

    public LoginController(Model model, LoginView loginWindow, DashboardView dashboard) {
        this.model = model;
        this.loginWindow = loginWindow;
        this.dashboard = dashboard;

        loginWindow.init();
        loginWindow.enterBtn.addActionListener(this);
        loginWindow.createAccBtn.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        // Login action
        if (e.getSource() == loginWindow.enterBtn) {
            boolean entered = Model.enterAccount(loginWindow.usernameField.getText(),
                    loginWindow.passwordField.getText());
            if (entered) {
                loginWindow.window.getContentPane().removeAll();
                dashboard.initializeDashboard(this);
                loginWindow.window.revalidate();
                loginWindow.window.repaint();
            } else {
                JOptionPane.showMessageDialog(null, "The account information does not exist.");
            }
        }

        // Create account screen
        if (e.getSource() == loginWindow.createAccBtn) {
            loginWindow.createAccWindow(this);
        }

        // Submit new account
        if (e.getSource() == loginWindow.submitBtn) {
            Model.createAccount(loginWindow.usernameCreateField.getText(), loginWindow.passwordCreateField.getText());
        }

        // Back button to login screen
        if (e.getSource() == loginWindow.backBtn) {
            loginWindow.window.getContentPane().removeAll();
            loginWindow.init();
            loginWindow.enterBtn.addActionListener(this);
            loginWindow.createAccBtn.addActionListener(this);
            loginWindow.window.revalidate();
            loginWindow.window.repaint();
        }

        // Handle profile menu options
        if (e.getSource() == dashboard.getChangeUserItem() || e.getSource() == dashboard.getLogoutItem()) {
            loginWindow.window.getContentPane().removeAll();
            loginWindow.init();
            loginWindow.enterBtn.addActionListener(this);
            loginWindow.createAccBtn.addActionListener(this);
            loginWindow.window.revalidate();
            loginWindow.window.repaint();
        }

        if (e.getSource() == dashboard.getSettingsItem()) {
            JOptionPane.showMessageDialog(loginWindow.window, "For Future Implementation", "Settings",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
