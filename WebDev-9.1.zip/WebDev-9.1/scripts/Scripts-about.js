
$(document).ready(function(){
    $("#accordion").accordion();
});
    
$(document).ready(function() {
    $("#tabs" ).tabs();
});